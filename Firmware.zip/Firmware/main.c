#include <STC8G.h>
#include <intrins.h>

#define FOSC 11059200UL
#define BAUD 9600

//Band to Voltage Look-up table
const float band_voltage_in[] = {0.33f, 0.67f, 1.00f, 1.33f, 1.67f, 2.00f, 2.33f, 2.67f, 3.00f, 3.33f, 3.67f, 4.00f};
const unsigned int band_voltage_out_int[]={188,377,753,942,1130,1319,1507,1695,1884,2072,2072,2072};
const char* band_names[] = {"1.8", "3.5", "7", "10", "14", "18", "21", "24", "28", "50", "144", "430"};

//IIC Pins
sbit SDA = P3^3;
sbit SCL = P3^2;

// MCP4725A0T
#define MCP4725_ADDR 0xC0

void delay_ms(int delay_time);
void Uart1_Init(void);
void UART_SendByte(char dat);
void UART_SendString(const char *s);
void ADC_Init(void);
unsigned int ADC_Read(unsigned char channel);
float ADC_ToVoltage(unsigned int adc_value);
void MCP4725_Write(unsigned int value);
int find_band_index(float voltage);

void main(void)
{
	unsigned int adc_value;
	float vunbias;
	unsigned int vin_raw;
	int band_index;
	char uart_buf[50];
	int last_band_choice=0;
	int counter=0;

	P3M0 = 0x00;
	P3M1 = 0x00;
	P5M0 = 0x00;
	P5M1 = 0x00;
	//Inits
	Uart1_Init();
	ADC_Init();
	//IIC Inits
	P_SW2 = 0x80;
	I2CCFG = 0xe0;
	I2CMSST = 0x00;
	//Give some time to ADC inits.
	delay_ms(100);

	UART_SendString("XPA125B <> FT-817/818 Interface\r\n");
	UART_SendString("Band auto switch MCU. By BG2KAJ\r\n");
    
	while(1)
	{
		//Read in ADC FT-818 band voltage.
		for(counter=0;counter<5;counter++)
		{
			adc_value += ADC_Read(4);
		}
		vin_raw=adc_value/5;
		adc_value=0;

		vunbias=ADC_ToVoltage(vin_raw);

		//Looking up for closet band.
		band_index = find_band_index(vunbias);
		if(last_band_choice!=band_index)
		{
			//DAC output proper XPA-125B band volage.
			MCP4725_Write(band_voltage_out_int[band_index]);
			last_band_choice=band_index;
		}
		
		//Debug message, You may never see this if you don't open the case.
		sprintf(uart_buf, "Vin: %fV, Band: %s Vout: %d \r\n",vunbias, band_names[band_index],band_voltage_out_int[band_index]);
		UART_SendString(uart_buf);

		delay_ms(100);
	}
}

// Delays
void delay_ms(int delay_time)	//@11.0592MHz
{
	unsigned char data i, j;

	while(delay_time>0)
	{
		_nop_();
		_nop_();
		_nop_();
		i = 11;
		j = 190;
		do
		{
			while (--j);
		} while (--i);
		delay_time--;
	}
}


// Serials.
void Uart1_Init(void)	//9600bps@11.0592MHz
{
	SCON = 0x50;		//8 bits and variable baudrate
	AUXR |= 0x40;		//imer clock is 1T mode
	AUXR &= 0xFE;		//UART 1 use Timer1 as baudrate generator
	TMOD &= 0x0F;		//Set timer work mode
	TL1 = 0xE0;			//Initial timer value
	TH1 = 0xFE;			//Initial timer value
	ET1 = 0;			//Disable Timer%d interrupt
	TR1 = 1;			//Timer1 start run
}


void UART_SendByte(char dat)
{
    SBUF = dat;
    while(!TI);
    TI = 0;
}

void UART_SendString(const char *s)
{
    while(*s)
    {
        UART_SendByte(*s++);
    }
}

// ADCs
void ADC_Init(void)
{
	//Pin
	P5M0 &= ~0x10; P5M1 |= 0x10; 
	//ADC configs.
	ADCCFG &= ~0x0f;
	ADCCFG |= 0x01;			//SPEED(1)
	ADCTIM = 0x2c;			//CSSETUP(0), CSHOLD(1), SMPDUTY(12)
	//Enable ADC
	ADC_CONTR = 0x80; 
}

unsigned int ADC_Read(unsigned char channel)
{
    unsigned int result;
    
    ADC_CONTR = 0xC0 | channel;
    _nop_();
    _nop_();
    while(!(ADC_CONTR & 0x20));
    ADC_CONTR &= ~0x20;
  
    result = (ADC_RES << 2) + ((ADC_RESL & 0xC0)>>6);
    
    return result;
}

float ADC_ToVoltage(unsigned int adc_value)
{
    return (adc_value * 4.971) / 1024.0;
}

// IIC hardware functions.
// Those codes was copied from STC official codes with permitts.
void Wait()
{
    while (!(I2CMSST & 0x40));
    I2CMSST &= ~0x40;
}

void Start()
{
    I2CMSCR = 0x01;
    Wait();
}

void SendData(char dat)
{
    I2CTXD = dat;
    I2CMSCR = 0x02;
    Wait();
}

void RecvACK()
{
    I2CMSCR = 0x03;
    Wait();
}

void Stop()
{
    I2CMSCR = 0x06;
    Wait();
}

// MCP4725
void MCP4725_Write(unsigned int value)
{
    Start();
		SendData(0xc0);
		RecvACK();
		SendData((value>>8)&0x0f);
		RecvACK();
		SendData(value&0xff);
		RecvACK();
	  Stop();
}

// Find the closet index
int find_band_index(float voltage)
{
    int i, closest_index = 0;
    float min_diff = 10.0;
    
    for(i = 0; i < 12; i++)
    {
        float diff = voltage - band_voltage_in[i];
        if(diff < 0) diff = -diff;
        
        if(diff < min_diff)
        {
            min_diff = diff;
            closest_index = i;
        }
    }
    
    return closest_index;
}
